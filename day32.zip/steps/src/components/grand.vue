<template>    
    <div class="box">
        <h2>Grand Parent Component</h2>
        <h3>{{value}}</h3>
        <button @click="updateValue(300)">Data from Grandfather</button>
        <FamParent/>
    </div>
</template>
 
<script>
    import FamParent from "./parent.vue"
    export default {
        name : "FamGrand",
        data(){
           return{
            value : 0
           }
        },
        components: { 
          FamParent
        },
        provide : {
            FamParent
        },
        methods :{
            updateValue(npower){
                return (npower+Math.round(Math.random()*3000))
            }
        }
    }
</script>
 
<style>
   .box{
    border:  2px solid rgb(221, 71, 71);
    padding: 10px;
    margin: 10px;
    text-align: left;
    max-width: 600px;
   }
</style>